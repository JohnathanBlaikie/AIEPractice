# Math for Games C\# - Unit Testing Sample

## Guidelines

You should use this repository as a template to create your own repo.

Once created, you are then able to re-implement your math classes for
Matrix, Vector, and Colors as well as binary functionality into this repository
and run the unit tests included against your code.

## License

MIT License - Copyright (c) 2019 Academy of Interactive Entertainment

For more information, see the [license][lic] file.

[lic]:LICENSE.md
