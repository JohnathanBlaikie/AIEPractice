Open \Release
Run CPPAssessments.exe