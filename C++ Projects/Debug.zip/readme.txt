Open \Release
Run Debugging Exercise.exe