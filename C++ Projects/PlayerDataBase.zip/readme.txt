Open \Release
Run PlayerDataBase.exe