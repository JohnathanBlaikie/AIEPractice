#pragma once

class Zergling
{
public:
	Zergling();
	~Zergling();

	int attack();
	void takeDamage(int damage);

};

